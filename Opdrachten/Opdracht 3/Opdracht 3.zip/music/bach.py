import muser as ms

bach = (
    (
        ('e*', 4),

    ),
    (
        ('g2', 8),

    )
)

muser = ms.Muser ()
muser.generate (bach)
