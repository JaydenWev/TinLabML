class Score:
	
	def calculateScore(){
    getTime()
    getSlip()
    getCollide()
    adjustPid()
    
    }
