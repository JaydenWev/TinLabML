import FileInteractorJSON as fi

fi.writeToFile('path.path', 'D:\Documents\School\Tinlab\Tinlab ML\TinLabML\Opdrachten\Opdracht 4\car\simpylc')
print(fi.readFromFile('path.path'))