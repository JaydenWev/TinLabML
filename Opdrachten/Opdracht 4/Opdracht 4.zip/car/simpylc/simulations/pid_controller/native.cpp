/*
====== Legal notices

Copyright (C) 2013 - 2021 GEATEC engineering

This program is free software.
You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY, without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the QQuickLicence for details.

The QQuickLicense can be accessed at: http://www.qquick.org/license.html

__________________________________________________________________________


 THIS PROGRAM IS FUNDAMENTALLY UNSUITABLE FOR CONTROLLING REAL SYSTEMS !!

__________________________________________________________________________

It is meant for training purposes only.

Removing this header ends your licence.
*/

int const analogInPin = A3;
int const analogOutPin = 2;

void setup () {
    // pinMode (analogInPin, INPUT);
    pinMode (analogOutPin, OUTPUT);
    Serial.begin(9600);
}

void loop () {
    nActIn = analogRead (analogInPin);
    cycle ();
    analogWrite  (analogOutPin, nOut);
    Serial.println (nActIn);  
}       

