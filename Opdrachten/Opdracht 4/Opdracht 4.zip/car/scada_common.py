listName = 'scada'
listValues = (False, False, False, 0, 0)

(
    enableDriveIndex,
    disableDriveIndex,
    driveEnabledIndex,
    steeringAngleIndex,
    targetVelocityIndex
) = range (len (listValues))
